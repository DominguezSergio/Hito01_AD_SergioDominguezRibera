package json;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser; //2.6

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class JsonController {
	String cadena = "";
	ArrayList<OJson> lista = new ArrayList<OJson>();
	int cont = 0;
	String n, a;
	String ed = "";
	int e;

	
	public TextField anaTexto;
	public Label verTexto;
	public TextField nombre;
	public TextField apellido;
	public TextField edad;
	public Label error;
	//
	
	
	
	public void leer() throws FileNotFoundException {
		verTexto.setOpacity(1);
		//
		JsonParser parser = new JsonParser();
        FileReader fr = new FileReader("archivo.json");
        JsonElement datos = parser.parse(fr);
        cadena = "";
		//
        if (datos.isJsonObject()) {
            JsonObject obj = datos.getAsJsonObject();
            java.util.Set<java.util.Map.Entry<String,JsonElement>> entradas = obj.entrySet();
            java.util.Iterator<java.util.Map.Entry<String,JsonElement>> iter = entradas.iterator();
            while (iter.hasNext()) {
                java.util.Map.Entry<String,JsonElement> entrada = iter.next();
                leer2(entrada.getValue());
            }
        }
        cadena = "";
	}//
	
	//
	public void anadir() throws FileNotFoundException {
		//
		JsonParser parser = new JsonParser();
        FileReader fr = new FileReader("archivo.json");
        JsonElement datos = parser.parse(fr);
		//
        if (datos.isJsonObject()) {
            JsonObject obj = datos.getAsJsonObject();
            java.util.Set<java.util.Map.Entry<String,JsonElement>> entradas = obj.entrySet();
            java.util.Iterator<java.util.Map.Entry<String,JsonElement>> iter = entradas.iterator();
            while (iter.hasNext()) {
                java.util.Map.Entry<String,JsonElement> entrada = iter.next();
                ana2(entrada.getValue());
            }
        }
        System.out.println("--" + lista.size() + "---");

        if (nombre.getText().equals("") || apellido.getText().equals("") || edad.getText().equals("")) {
        	System.out.println("Campos vacios");
        	error.setText("CAMPOS VACIOS");
        }
        else {
        	error.setText("");
        	System.out.println(edad.getText());
        	n = nombre.getText();
            a = apellido.getText();
            ed = edad.getText();
            e = Integer.parseInt(ed);
            OJson o = new OJson(n, a, e);
            lista.add(o);
        }
               
        Gson gson = new Gson();
		String jsonString = null;
		String personas = "{peronas:[\n";
        for(int i = 0; i<lista.size(); i++) {
        	if(i<lista.size()-1) {
        		jsonString = "{" + "'nombre':" + lista.get(i).getNombre() + ",'apellido':" + lista.get(i).getApellido() + ",'edad':" + lista.get(i).getEdad() + "}";
            	personas = personas + jsonString + ",\n";
        	}
        	else {
        		jsonString = "{" + "'nombre':" + lista.get(i).getNombre() + ",'apellido':" + lista.get(i).getApellido() + ",'edad':" + lista.get(i).getEdad() + "}";
            	personas = personas + jsonString + "\n]}";
        	}
        	System.out.println("<>"+jsonString+"<>");
        }
        System.out.println(personas);
        System.out.println("\n");
        
        FileWriter flwriter = null;
		String ruta = ".\\archivo.json";
        File archivo = new File(ruta);
        BufferedWriter bw = null;
        try {
        	//
        	flwriter = new FileWriter(archivo);
			BufferedWriter bfwriter = new BufferedWriter(flwriter);
			bfwriter.write(personas);
			bfwriter.close();
        	//
		} catch (IOException e) {
			e.printStackTrace();
		}
        System.out.println(lista.get(0));
        
        lista.clear();
        nombre.setText("");
        apellido.setText("");
        edad.setText("");
	}//----
	
	
	
	
	
	
	
	
	
	
	
	public void leer2(JsonElement datos) throws FileNotFoundException {
        if (datos.isJsonObject()) {
            JsonObject obj = datos.getAsJsonObject();
            java.util.Set<java.util.Map.Entry<String,JsonElement>> entradas = obj.entrySet();
            java.util.Iterator<java.util.Map.Entry<String,JsonElement>> iter = entradas.iterator();
            while (iter.hasNext()) {
                java.util.Map.Entry<String,JsonElement> entrada = iter.next();
                if(entrada.getKey() .equals("edad")) {
                	cadena = cadena + entrada.getKey() + ":" + entrada.getValue() + "\r" + "----\r";
                }else {
                	cadena = cadena + entrada.getKey() + ":" + entrada.getValue() + "\r";
                }
                
                verTexto.setText(cadena);
                
                leer2(entrada.getValue());
            }
            System.out.println("vuelta");
        }
        else if(datos.isJsonArray()){
			
			JsonArray array = datos.getAsJsonArray();
			Iterator<JsonElement> iter = array.iterator();
			
			while (iter.hasNext()) {
	            JsonElement entrada = iter.next();
	            leer2(entrada);
	        }
		}
		else if(datos.isJsonPrimitive()) {
		}
		else if(datos.isJsonNull()) {
		} //Cierra el if
        
	}
	public void ana2(JsonElement datos) throws FileNotFoundException {
		if (datos.isJsonObject()) {
            JsonObject obj = datos.getAsJsonObject();
            java.util.Set<java.util.Map.Entry<String,JsonElement>> entradas = obj.entrySet();
            java.util.Iterator<java.util.Map.Entry<String,JsonElement>> iter = entradas.iterator();
            while (iter.hasNext()) {
                java.util.Map.Entry<String,JsonElement> entrada = iter.next();
                if(entrada.getKey() .equals("nombre")) {
                	n = entrada.getValue().toString();
                	System.out.println(1);
                	cont++;
                }
                else if(entrada.getKey() .equals("apellido")) {
                	a = entrada.getValue().toString();
                	System.out.println(2);
                	cont++;
                }
                else if(entrada.getKey() .equals("edad")){
                	e = Integer.parseInt(entrada.getValue().toString());
                	System.out.println(3);
                	cont++;
                }
                if(cont == 3) {
                	OJson o = new OJson(n, a, e);
                	lista.add(o);
                	System.out.println("|"+cont+"|");
                	cont = 0;
                }
                System.out.println("/LISTADO/");
                for (int i=0; i<lista.size(); i++) {
                	System.out.println("---");
                	System.out.println(lista.get(i).getNombre() + " " + lista.get(i).getApellido() + " " + lista.get(i).getEdad());
                	System.out.println("---");
                }
                System.out.println("/CIERRA/");

                ana2(entrada.getValue());
            }
            
        }
        else if(datos.isJsonArray()){
			JsonArray array = datos.getAsJsonArray();
			Iterator<JsonElement> iter = array.iterator();

			while (iter.hasNext()) {
	            JsonElement entrada = iter.next();
	            ana2(entrada);
	        }
		}
		else if(datos.isJsonPrimitive()) {
		}
		else if(datos.isJsonNull()) {
		} //Cierra el if
		
	}
	
}
/*
{peronas:[
{"nombre":"1","apellido":"Dominguez","edad":1},
{"nombre":"2","apellido":"martin","edad":2},
{"nombre":"3","apellido":"gomez","edad":3}
]}
 */

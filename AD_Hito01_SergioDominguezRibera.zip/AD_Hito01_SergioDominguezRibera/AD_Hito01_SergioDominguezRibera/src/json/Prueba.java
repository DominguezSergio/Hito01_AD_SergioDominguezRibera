package json;

import java.io.FileNotFoundException;
import java.io.FileReader;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Prueba {{
	
    leer();
}

public void leer() {
	// TODO Auto-generated method stub
	//
	
}}

package xml;

public class Oxml {
	private String nombre, apellido, edad;
	
	public Oxml() {
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public String getEdad() {
		return edad;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public void setEdad(String edad) {
		this.edad = edad;
	}
	
	
	
}
